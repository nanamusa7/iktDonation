package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.*;

import java.util.ArrayList;

/**
 * Servlet implementation class SearchDonationList
 */
@WebServlet(name = "controller.SearchDonationList", urlPatterns = { "/SearchDonationList" }, loadOnStartup = 1)
public class SearchDonationList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchDonationList() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html; charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		response.setHeader("Cache-Control", "nocache");
		response.setCharacterEncoding("utf-8");

		try {
			// 取得搜尋列資料
			ConditionInfo condi = new ConditionInfo();

			ArrayList<DonationInfo> dntList = new ArrayList<DonationInfo>();

			// 日期,姓名,編號,道場,單位,金額
			condi.setsDateInfo((String) request.getParameter("search_date_start"));
			condi.seteDateInfo((String) request.getParameter("search_date_end"));
			condi.setName((String) request.getParameter("search_name"));
			condi.setIdDnt((String) request.getParameter("search_dnt_id"));
			condi.setIktBranch((String) request.getParameter("search_iktbranch"));
			condi.setOrganization((String) request.getParameter("search_organization"));
			condi.setAmount((String) request.getParameter("search_amount"));

			dntList = Donation.GetDonationList(condi);

			// arraylist -> json
			
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
