package controller;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ConditionInfo {

	/* 捐贈資料欄位 */
	private String sDate;//起始日期
	private String eDate;//結束日期
	private	String name;//姓名
	private	String idDnt;//感謝函編號
	private	String iktBranch;//道場
	private	String organization;//單位
	private	String amount;//捐贈金額
	
	ConditionInfo() {
		
	}
	
	public String getsDateInfo() {
		return this.sDate;
	}

	public void setsDateInfo(String sDate) {
		this.sDate = sDate;
	}

	public String geteDateInfo() {
		return eDate;
	}

	public void seteDateInfo(String eDate) {
		this.eDate = eDate;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
	
	public String getIdDnt() {
		return idDnt;
	}

	public void setIdDnt(String idDnt) {
		this.idDnt = idDnt;
	}	
	
	public String getIktBranch() {
		return iktBranch;
	}

	public void setIktBranch(String iktBranch) {
		this.iktBranch = iktBranch;
	}	

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}	

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}	
	
}
