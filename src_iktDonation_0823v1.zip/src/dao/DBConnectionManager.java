package dao;
 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/* import constants.GoMyPayContants;
 * 	- dbURL "db位置;帳號;密碼"
 * "jdbc:sqlserver://118.163.153.248:14330;
 *  databaseName=gomypay;
 *  user=miway;password=w@De1974#%@"
 */


//DBConnectionManager
//getConnection //status

public class DBConnectionManager {
 
    private Connection connection;
     
    public DBConnectionManager() throws ClassNotFoundException, SQLException{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver"); //註冊driver
        this.connection = DriverManager.getConnection("jdbc:sqlserver://118.163.153.248:14330"/*dbURL*/); //connection
    }
     
    public Connection getConnection(){
        return this.connection;
    }
}
