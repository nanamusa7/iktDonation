package dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import java.sql.Date;


public class Donation {

	//private static String dTable = "DonationList";
	
	public static ArrayList<controller.DonationInfo> GetDonationList(controller.ConditionInfo condi) {
		DBConnectionManager manager;

		try {
			manager = new DBConnectionManager();
			Connection conn = manager.getConnection();
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			
			ArrayList<controller.DonationInfo> dntList = new ArrayList<controller.DonationInfo>();
			controller.DonationInfo tmp;
			
			boolean fCondi = false;
			String qSearch = "", qWhere = "";
			
			try {
				fCondi = emptyCheckAll(condi);
				qSearch = "SELECT * FROM donation ";//USER_ID = ?";
				
				// search condition is not empty
				if(!fCondi) { 
					// 1:name, 2:iktBranch, 3:organization, 4:amount, 5:id, 6:date
					qWhere = "WHERE dnt_donor_name = ? "
								+ "AND dnt_ikt_branch_id = ? "
								+ "AND dnt_organization = ? "
								+ "AND dnt_amount = ? "
								+ "AND dnt_id = ? "
								+ "AND dnt_date BETWEEN ? and ?";
					
					pstmt.setString(1, condi.getName());
					pstmt.setString(2, condi.getIktBranch());
					pstmt.setString(3, condi.getOrganization());
					pstmt.setString(4, condi.getAmount());
					pstmt.setString(5, condi.getIdDnt());
					pstmt.setString(6, condi.getsDateInfo());
					pstmt.setString(7, condi.geteDateInfo());
					
				}
				
				pstmt = conn.prepareStatement( qSearch + qWhere + "ORDER BY date DESC");
				rs = pstmt.executeQuery();
				
	            while (rs.next()) {
	            	tmp = new controller.DonationInfo();
	            	
	            	tmp.setName(rs.getString("dnt_donor_name"));
	            	tmp.setIktBranch(rs.getString("dnt_ikt_branch_id"));
	            	tmp.setOrganization(rs.getString("dnt_organization"));
	            	tmp.setAmount(rs.getString("dnt_amount"));
	            	tmp.setIdDnt(rs.getString("dnt_id"));
	            	tmp.setDateInfo(rs.getString("dnt_date"));

	            	dntList.add(tmp);
	            }

	            return dntList;

			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				try {
					rs.close();
					pstmt.close();
					try {
						conn.close();
					} catch (Exception e) {
						e.printStackTrace();
					}// conn.close
				} catch (SQLException e) {
				}// pstmt & rs close
			}
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return null;
	}
	
	public static boolean emptyCheckAll(controller.ConditionInfo cnd){
		boolean flagCheck = false;
		
		flagCheck = cnd.getName().isEmpty()
					&& cnd.getIktBranch().isEmpty()
					&& cnd.getOrganization().isEmpty()
					&& cnd.getIdDnt().isEmpty()
					&& cnd.getAmount().isEmpty()
					&& cnd.getsDateInfo().isEmpty()
					&& cnd.geteDateInfo().isEmpty();
				
		return flagCheck;
	}
	
}
